#include "Car.h"
using namespace std;



const Car & Car::operator = (const Car &source){
    if (this == &source) return (*this);
    type = source.type;
    make = source.make;
    model = source.make;
    speed = source.speed;
    return (*this);
}


bool Car::operator != (const Car &source) const{
    return this->speed != source.speed;
}

bool compare(const Car &c1, const Car &c2) { return c1.speed < c2.speed; }


ostream &operator << (ostream &out, const Car &x){
    out << "Type: " << x.type << endl;
    out << "Make: " << x.make << endl;
    out << "Model: " << x.model << endl;
    out << "Speed: " << x.speed << endl;
    return out;
}


ostream &operator >> (ostream &in, Car &x){
    cout << "Enter type: ";
    cin >> (x.type);
    cout << "Enter make: ";
    cin >> (x.make);
    cout << "Enter model: ";
    cin >> (x.model);
    cout << "Enter speed: ";
    cin >> (x.speed);
    return in;
}
