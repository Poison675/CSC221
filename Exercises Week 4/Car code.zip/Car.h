#ifndef CAR_H
#define CAR_H

#include <string>
#include <iostream>
using namespace std;

class Car{
public:
    string type;
    string make;
    string model;
    int speed;

    Car(string type = "null", string make = "null", string model = "null", int speed = 0) : 
                    type(type), make(make), model(model), speed(speed){}
    const Car &operator = (const Car &source);
    bool operator != (const Car &source) const;
    bool operator<(const Car& other) const {
        return speed < other.speed; 
    }
    friend bool compare(const Car &c1, const Car $c2);
    friend ostream &operator << (ostream &out, const Car &x);
    friend ostream &operator >> (ostream &in, Car &x);   
};

bool compare(const Car &c1, const Car &c2);
ostream &operator << (ostream &out, const Car &x);
ostream &operator >> (ostream &in, Car &x);  
#endif