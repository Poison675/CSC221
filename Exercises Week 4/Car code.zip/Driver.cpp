/*
 * Aidan Veselka: CSCE 221
 * CRN 599
 * Lecture notes problem: Creating a car class.
 */

#include <string>
#include <iostream>
#include <vector>
#include <algorithm> // for sort

using namespace std;

#include "Car.h"

int main(){
    vector<Car> *cars = new vector<Car>;

    Car c1("Honda", "CRV", "2014", 100);
    Car c2("Telsa", "S", "2020", 156);
    Car c3("Toyota", "Civic", "2016", 110);
    Car c4("Porsche", "911", "2024", 152);
    Car c5("Ford", "F-150", "210", 93);

    cars->push_back(c1);
    cars->push_back(c2);
    cars->push_back(c3);
    cars->push_back(c4);
    cars->push_back(c5);

    cout << "Printing original list of cars: " << endl;
    for (vector<Car>::const_iterator i = cars->begin(); i != cars->end(); ++i)
    { cout << (*i) << endl; }

    sort(cars->begin(), cars->end());

    cout << "Printing sorted list: " << endl;
    for (vector<Car>::const_iterator i = cars->begin(); i != cars->end(); ++i)
    { cout << (*i) << endl; }
}
