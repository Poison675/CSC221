#include <string>
#include <iostream>
#include <stack>
#include <queue>

using namespace std;

#include "Student.h"

template <class Student>
void displayStack(stack <Student> &x){
    cout << "DISPLAY STACK: " << endl;
    while (!x.empty()){
        cout << x.top() << endl;
        cout << endl;
        x.pop();
    }
	// The stack last member after this function is called gets popped.
}

template <class Student>
void peek(stack <Student> &x){
	cout << "Peeking at top item on stack: " << endl;
	cout << x.top() << endl;
	cout << endl;
}

void displayQueue(queue <Student> *x){
    cout << "Displaying queue: " << endl;
    while (!x->empty()){
        cout << x->front() << endl;
        cout << endl;
        x->pop();
    }
}

void displayQueue(queue <int> x){
    cout << "Displaying queue: " << endl;
    while (!x.empty()){
        cout << x.front() << endl;
        cout << endl;
        x.pop();
    }
}

int main()
{

	queue <int> demo; // notice stack is NOT in blue
	queue <Student> demo2; // custom datatype
	queue <Student> *CMSC341 = new queue <Student>; // Heap stack

	Student temp; // need a temp, can reuse over and over AFTER we push it in
	temp.Fname = "Mr";
	temp.Lname = "Lupoli";
	temp.score = 99;

	demo.push(17);
	demo2.push(Student(temp));
	CMSC341->push(Student(temp));

	Student *excellent = new Student("Blair", "Lupoli", 100);
	CMSC341->push(*excellent);

	Student notSoExcellent("Tom", "Hanks", 17);
	CMSC341->push(notSoExcellent);

	displayQueue(demo);
	displayQueue(&demo2);
	displayQueue(CMSC341);

	//This leads to a segmentation fault
	// peek(demo);
	// peek(demo2);
	// peek(*CMSC341);

	delete(CMSC341);

	return 0;

}
